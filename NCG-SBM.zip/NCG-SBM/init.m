function tOmega = init(N,K)

    tOmega = randn(N,K);
end